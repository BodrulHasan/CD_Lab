num = 17

if num % 2 != 0 and num % 3 == 0:
    print("It is ODD and Divisible by 3")
elif num % 2 != 0 and num % 3 != 0:
    print("ODD and Not Divisible by 3")
elif num % 2 == 0 and num % 3 == 0:
    print("Even and Divisible by 3")

